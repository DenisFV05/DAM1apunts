set SERVEROUTPUT on
DECLARE
    dept1 departments.department_id%type;
    dept2 departments.department_id%type;
BEGIN
    dept1:=20;
    dept2:=110;
    update employees
    set department_id = dept1
    where department_id = dept2;
    dbms_output.put_line('files modificades '||sql%rowcount);
    commit;
exception 
    when others then 
        rollback;
        dbms_output.put_line(sqlerrm);
end;

-- query per comptar els treballadors d'un departament i comprovar 
-- així que coincideix amb el comptador de la taula departaments.
select department_id,employee_count,
       (select count(*) from employees e 
       where e.department_id=d.department_id) as emp_count
  from departments d
where d.DEPARTMENT_ID in (10,20,70,90,110)
 order by emp_count;

-- query per actualitzar els treballadors d'un departament 
-- al comptador de la taula departaments.
 update departments d
 set employee_count=(select count(*) from employees e 
       where e.department_id=d.department_id);
